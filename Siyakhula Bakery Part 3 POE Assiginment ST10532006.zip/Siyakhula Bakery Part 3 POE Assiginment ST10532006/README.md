# Siyakhula Bakery Website – Part 3

## Project overview
This is the Part 3 extension of the Siyakhula Bakery website created in Parts 1 and 2. The website uses HTML5, CSS3 and vanilla JavaScript. It keeps the original bakery identity, images and cream, brown and soft-orange visual style.

## Pages and files
- `index.html` – home page and illustrative Durban service-area map.
- `Products.html` – products generated from JavaScript data, with search and sorting.
- `enquiry.html` – product and custom-cake enquiry form with validation.
- `contact.html` – general contact form with validation.
- `Gallery.html` – image gallery with an accessible lightbox.
- `Cakes.html` and `Contact.html` – compatibility redirects for earlier Part 2 links.
- `styles.css` – shared responsive design and Part 3 styling.
- `script.js` – navigation, dynamic products, search/sort, lightbox, form validation/AJAX and map.
- `robots.txt`, `sitemap.xml` – crawler instructions and site map.
- `Images/` – supplied bakery images and logo.

## Functionality implemented
1. Responsive navigation menu with accessible expanded state.
2. Dynamic product cards created from a JavaScript array.
3. Product search and sorting by name or price.
4. Gallery lightbox using the HTML dialog element.
5. Leaflet interactive map with OpenStreetMap tiles. The marker indicates Durban city centre as a general service-area reference only; it is not an exact bakery address.
6. Enquiry form requests customer details, product, quantity, required date and request details. JavaScript checks required fields and prevents past dates.
7. Contact form requests name, email, optional phone, message type and a full message.
8. Both forms submit asynchronously using the FormSubmit AJAX endpoint. The recipient address must activate the first confirmation email before live email delivery will work. A static website cannot send email on its own; the form service provides the server-side email handling.

## Form setup before publishing
The demo recipient in both form actions is `hello@siyakhulabakery.co.za`, based on the fictional contact details already used in this project. FormSubmit requires the mailbox owner to complete its activation/confirmation step. Replace this address in `enquiry.html` and `contact.html` if the lecturer wants a different recipient. Do not claim a form email has been delivered until a real test email is received.

## SEO work
- Unique title and meta description on each main page.
- Relevant keywords included naturally in page headings and copy.
- Logical heading structure and descriptive image alternative text.
- Internal links between the home, product, enquiry, gallery and contact pages.
- Responsive/mobile-friendly layout and lazy loading on non-critical images.
- `robots.txt` allows crawling and points to the sitemap.
- `sitemap.xml` lists the main pages.
- Descriptive filenames are used where the supplied image names allow it.
- Open Graph/social sharing metadata can be added when a real production domain and social profile are available.

## Off-page and local SEO plan
The bakery is a fictional academic business, so no real backlinks or social accounts have been claimed. For a real business, request links from local business directories, community organisations and suppliers; share genuine bakery content on Facebook and Instagram; and create/verify a Google Business Profile with the correct address, phone number and opening hours. Never publish a made-up street address or ask customers to review a business that does not exist.

## Performance and security
Images use lazy loading where appropriate and fixed dimensions where useful to reduce layout movement. CSS includes reduced-motion support. Netlify headers add basic browser security headers. Use HTTPS through the hosting platform. These are baseline protections, not a guarantee against every attack. Do not collect payment-card details in these forms.

## Testing checklist
- [ ] Open `index.html` and test every navigation link.
- [ ] Test layout at desktop, tablet and mobile widths using browser Developer Tools.
- [ ] Search for `cake`, sort products by name and by price, and test a no-results search.
- [ ] Open and close every gallery image using the lightbox.
- [ ] Submit each form empty and confirm browser/JavaScript validation appears.
- [ ] Test an invalid email, short message, invalid phone format and a past enquiry date.
- [ ] Activate FormSubmit for the recipient and submit a real test form; confirm the email arrives.
- [ ] Check the map loads when an internet connection is available.
- [ ] Check `robots.txt` and `sitemap.xml` after deployment.
- [ ] Run the deployed website on a phone and test all buttons and forms.

## Deploying for free with Netlify
1. Extract the ZIP file. Open the folder containing `index.html`, `styles.css`, `script.js` and `Images` in VS Code.
2. Test locally by opening `index.html` in a browser (Live Server is recommended).
3. Sign in to Netlify and choose **Add new site → Deploy manually**.
4. Drag the website project folder (the folder containing `index.html`) into the deploy area. Do not upload only the ZIP's outer folder if it creates an extra nested folder.
5. Netlify will provide a temporary public URL. Open it and test all pages.
6. Replace `example.netlify.app` in `robots.txt`, `sitemap.xml` and canonical link tags with the actual Netlify site URL, then redeploy.
7. Add the deployed URL to Google Search Console and submit `/sitemap.xml` if required.

## GitHub workflow
Create a repository, add the extracted project files, commit regularly and push to the remote repository. Suggested commit messages:
- `Correct Part 2 feedback and image paths`
- `Add SEO titles descriptions and crawler files`
- `Add dynamic product search and sorting`
- `Add gallery lightbox and interactive map`
- `Add validated enquiry and contact forms`
- `Update README with Part 3 testing and deployment`

## Changelog
### Part 2 feedback corrections completed during Part 3
- Replaced broken image references with the exact filenames found in the supplied Images folder, including the bread image.
- Updated navigation to point to the new enquiry page and lowercase contact page while retaining compatibility redirect pages for older links.
- Improved image descriptions and loading behaviour for accessibility and performance.
- Updated the existing README so the Part 2 work and Part 3 additions are recorded together. Check the actual lecturer feedback and add any further specific corrections here before submission.

### Part 3 functionality and SEO
- Added a dynamic product catalogue generated from a JavaScript array, with live search, sorting and a result count.
- Added a gallery lightbox so visitors can open product photographs in a larger dialog and close it with a button or by clicking the backdrop.
- Added a Leaflet/OpenStreetMap interactive map. The marker is labelled as a general Durban service-area reference and not an exact bakery location.
- Created `enquiry.html` with name, email, phone, product, quantity, required date and details fields. Added HTML5 constraints and JavaScript validation, including a rule against past dates.
- Created `contact.html` with name, email, optional phone, message type and full message fields. Added HTML5 and JavaScript validation.
- Added asynchronous form submission through FormSubmit. The recipient must activate the email service and test delivery before this can be described as fully live.
- Added unique page titles, meta descriptions, relevant bakery keywords, semantic headings, image alt text and internal links.
- Added `robots.txt`, `sitemap.xml`, lazy loading and basic Netlify security headers.
- Added Netlify deployment, GitHub commit and testing instructions.

## References
- Google Search Central. (n.d.). *SEO Starter Guide*. https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- Google Search Central. (n.d.). *Build and submit a sitemap*. https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap
- MDN Web Docs. (n.d.). *Constraint validation*. https://developer.mozilla.org/en-US/docs/Web/HTML/Constraint_validation
- MDN Web Docs. (n.d.). *Fetch API*. https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
- Leaflet. (n.d.). *Leaflet Quick Start Guide*. https://leafletjs.com/examples/quick-start/
- OpenStreetMap. (n.d.). *Copyright and licence*. https://www.openstreetmap.org/copyright
- FormSubmit. (n.d.). *AJAX form submission*. https://formsubmit.co/ajax-documentation
- Netlify. (n.d.). *Deploy manually*. https://docs.netlify.com/site-deploys/create-deploys/#deploy-with-drag-and-drop

**Academic note:** Siyakhula Bakery and the contact information are fictional project assumptions. The prices are estimates for demonstration only. Replace the placeholder canonical domain and sitemap domain with the actual deployed Netlify URL before final submission.
