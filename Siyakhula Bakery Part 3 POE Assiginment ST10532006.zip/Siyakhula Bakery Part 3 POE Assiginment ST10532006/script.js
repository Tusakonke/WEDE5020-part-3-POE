/* Siyakhula Bakery - Part 3 JavaScript */
'use strict';
document.addEventListener('DOMContentLoaded', () => {
  // Responsive navigation
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('header nav');
  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      const opened = nav.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(opened));
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open'); menuToggle.setAttribute('aria-expanded', 'false');
    }));
  }

  // Product content is generated from a JavaScript data array.
  const products = [
    {name:'Celebration Cakes', category:'Cakes', price:250, description:'Custom and simple cakes for birthdays and special days.', image:'Images/CAKE.jpeg', alt:'Celebration cake'},
    {name:'Cupcakes', category:'Cupcakes', price:12, description:'Soft cupcakes with different flavours and toppings.', image:'Images/CUPCAKE.jpeg', alt:'Decorated cupcakes'},
    {name:'Fresh Bread', category:'Bread', price:18, description:'Fresh bread for breakfast, lunch and family meals.', image:'Images/Bread.jpeg', alt:'Fresh bread loaf'},
    {name:'Savoury Snacks', category:'Snacks', price:15, description:'Snacks for school, work and small events.', image:'Images/SNACKS.jpeg', alt:'Savoury bakery snacks'},
    {name:'Cookies', category:'Snacks', price:10, description:'A sweet treat to enjoy with tea or coffee.', image:'Images/COOKIES.jpeg', alt:'Fresh cookies'},
    {name:'Event Boxes', category:'Events', price:180, description:'A selection of treats for meetings and celebrations.', image:'Images/EVENT BOXES.jpeg', alt:'Assorted event treat boxes'}
  ];
  const list = document.querySelector('#product-list');
  const search = document.querySelector('#product-search');
  const sort = document.querySelector('#product-sort');
  const count = document.querySelector('#product-count');
  function renderProducts() {
    if (!list) return;
    const term = (search?.value || '').trim().toLowerCase();
    let visible = products.filter(p => `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(term));
    if (sort?.value === 'name') visible.sort((a,b) => a.name.localeCompare(b.name));
    if (sort?.value === 'price') visible.sort((a,b) => a.price - b.price);
    list.innerHTML = visible.length ? visible.map(p => `<article class="product-card"><img src="${p.image}" alt="${p.alt}" loading="lazy" width="600" height="400"><p class="eyebrow">${p.category}</p><h2>${p.name}</h2><p>${p.description}</p><p><strong>From R${p.price}${p.name === 'Cupcakes' ? ' each' : ''}</strong></p><a class="text-link" href="enquiry.html">Enquire about this product</a></article>`).join('') : '<p class="no-results">No products match your search. Try another word.</p>';
    if (count) count.textContent = `${visible.length} product${visible.length === 1 ? '' : 's'} shown`;
  }
  if (list) { renderProducts(); search?.addEventListener('input', renderProducts); sort?.addEventListener('change', renderProducts); }

  // Accessible image lightbox
  const dialog = document.querySelector('#lightbox');
  if (dialog) {
    const largeImage = dialog.querySelector('img');
    const caption = dialog.querySelector('p');
    document.querySelectorAll('.gallery-image').forEach(button => button.addEventListener('click', () => {
      const img = button.querySelector('img'); largeImage.src = img.src; largeImage.alt = img.alt;
      caption.textContent = button.closest('figure')?.querySelector('figcaption')?.textContent || img.alt;
      dialog.showModal();
    }));
    dialog.querySelector('.lightbox-close')?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });
  }

  // Form validation and AJAX email submission. The endpoint requires recipient activation.
  async function setupForm(formId, errorId, successId, kind) {
    const form = document.getElementById(formId); if (!form) return;
    const error = document.getElementById(errorId), success = document.getElementById(successId);
    form.addEventListener('submit', async event => {
      event.preventDefault(); error.textContent = ''; success.textContent = '';
      if (kind === 'enquiry') {
        const date = form.querySelector('[name="required_date"]');
        if (date && date.value && new Date(`${date.value}T00:00:00`) < new Date(new Date().toDateString())) {
          date.setCustomValidity('Please choose today or a future date.');
        } else if (date) date.setCustomValidity('');
      }
      if (!form.checkValidity()) { form.reportValidity(); error.textContent = 'Please correct the highlighted fields and try again.'; return; }
      const submit = form.querySelector('[type="submit"]'); submit.disabled = true; submit.textContent = 'Sending…';
      try {
        const response = await fetch(form.action, { method:'POST', body:new FormData(form), headers:{'Accept':'application/json'} });
        const result = await response.json();
        if (!response.ok || result.success === 'false' || result.success === false) throw new Error(result.message || 'The message could not be sent.');
        success.textContent = kind === 'enquiry' ? 'Thank you! Your enquiry was submitted. We will respond with pricing and availability.' : 'Thank you! Your message was sent to Siyakhula Bakery.';
        form.reset();
      } catch (err) {
        error.textContent = 'The online email service is not active yet or could not be reached. Please email hello@siyakhulabakery.co.za directly, or try again later.';
      } finally { submit.disabled = false; submit.textContent = kind === 'enquiry' ? 'Submit enquiry' : 'Send message'; }
    });
  }
  setupForm('enquiry-form','enquiry-error','enquiry-success','enquiry');
  setupForm('contact-form','contact-error','contact-success','contact');

  // Leaflet map: broad city-centre marker only, not a claimed shop address.
  const mapElement = document.getElementById('bakery-map');
  if (mapElement && window.L) {
    const map = L.map(mapElement).setView([-29.8587, 31.0218], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).addTo(map);
    L.marker([-29.8587,31.0218]).addTo(map).bindPopup('Durban city centre – general service area, not an exact bakery address.');
  }
});
